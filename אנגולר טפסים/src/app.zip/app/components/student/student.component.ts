import { Component, Input } from '@angular/core';
import { Student } from '../../models/student';
import {StudentDetailsComponent} from '../studentDetails/studentDetails.component';
@Component({
  selector: 'app-student',
  standalone: true,
  imports: [StudentDetailsComponent],
  templateUrl: './student.component.html',
  styleUrl: './student.component.css'
})
export class StudentComponent {
  
  currentStudent!: Student;
  showAddPannel: boolean = false;
  allStudent: Student[] = [
    new Student(1, "Rachely", "Levi", 18, "03850328", 99, "Rabbi Akiva",true),
    new Student(2, "Dasi", "Vitan", 56, "75333333", 78, "Eliezer",true),
    new Student(3, "Mini", "Levi", 12, "876543", 56, "Hirsch",true),
    new Student(4, "Rachely", "Levi", 18, "03850328", 99, "Rabbi Akiva",true),
    new Student(5, "Dasi", "Vitan", 56, "75333333", 78, "Eliezer",true),
    new Student(6, "Mini", "Levi", 12, "876543", 56, "Hirsch",true)
  ];
  Delete(id: number) {
    this.allStudent = this.allStudent.filter(student => student.id != id);
  }
  Edit(student: Student) {
    this.currentStudent = student;
  }

  Add() {
    this.showAddPannel = true;
  }
}
